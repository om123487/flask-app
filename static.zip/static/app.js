const historyKey = "phishguard-history-v1";
const form = document.getElementById("scan-form");
const input = document.getElementById("url-input");
const errorBox = document.getElementById("form-error");
const emptyState = document.getElementById("scan-empty");
const resultPanel = document.getElementById("result-panel");
const scanButton = form.querySelector("button[type='submit']");

const statusClass = (status) => status.toLowerCase();
const escapeHtml = (value) =>
  String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[character]));

function showError(message) {
  errorBox.textContent = message;
  errorBox.hidden = false;
}

function clearError() {
  errorBox.textContent = "";
  errorBox.hidden = true;
}

function recommendationFor(status) {
  if (status === "Phishing") {
    return "Do not enter credentials, approve payments, download files, or continue. Use the official app or type the known domain manually.";
  }
  if (status === "Suspicious") {
    return "Pause before continuing. Verify the sender and destination through a separate trusted channel.";
  }
  return "This URL looks comparatively safe, but no URL-only scanner can guarantee a website is safe.";
}

function scoreCaption(status) {
  if (status === "Phishing") return "High exposure";
  if (status === "Suspicious") return "Review required";
  return "Low exposure";
}

function renderIndicators(signals) {
  const list = document.getElementById("indicator-list");
  list.innerHTML = signals.map((signal) => {
    const isPositive = signal.severity === "positive";
    const label = isPositive ? "PASS" : signal.severity === "danger" ? "ALERT" : "CHECK";
    const points = signal.points ? `+${signal.points} pts` : "CLEAR";
    return `
      <div class="indicator is-${escapeHtml(signal.severity)}">
        <span class="indicator-mark">${label}</span>
        <div><strong>${escapeHtml(signal.label)}</strong><p>${escapeHtml(signal.detail)}</p></div>
        <span class="indicator-points">${points}</span>
      </div>`;
  }).join("");
}

function renderResult(result) {
  const ring = document.getElementById("score-ring");
  const badge = document.getElementById("result-badge");
  const recommendation = document.getElementById("recommendation");
  const normalizedUrl = document.getElementById("normalized-url");
  const angle = `${result.score * 3.6}deg`;
  const color = result.status === "Safe" ? "#49eda6" : result.status === "Suspicious" ? "#f6b860" : "#ff6c82";

  document.getElementById("result-title").textContent = `${result.status} URL`;
  document.getElementById("result-verdict").textContent = result.verdict;
  document.getElementById("score-value").textContent = `${result.score}%`;
  document.getElementById("score-caption").textContent = scoreCaption(result.status);
  document.getElementById("result-host").textContent = result.hostname;
  document.getElementById("result-confidence").textContent = `${result.confidence}%`;
  document.getElementById("result-count").textContent = String(result.signals.filter((signal) => signal.severity !== "positive").length).padStart(2, "0");
  document.getElementById("recommendation-text").textContent = recommendationFor(result.status);
  normalizedUrl.textContent = result.normalized_url;

  ring.style.setProperty("--score-angle", angle);
  ring.style.setProperty("--ring-color", color);
  badge.textContent = result.status.toUpperCase();
  badge.className = `result-badge badge-${statusClass(result.status)}`;
  recommendation.className = `recommendation recommendation-${statusClass(result.status)}`;
  renderIndicators(result.signals);

  emptyState.hidden = true;
  resultPanel.hidden = false;
  resultPanel.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function getHistory() {
  try {
    return JSON.parse(localStorage.getItem(historyKey) || "[]");
  } catch {
    return [];
  }
}

function saveHistory(result) {
  const history = getHistory().filter((item) => item.url !== result.normalized_url);
  history.unshift({
    url: result.normalized_url,
    status: result.status,
    score: result.score,
    timestamp: new Date().toISOString()
  });
  localStorage.setItem(historyKey, JSON.stringify(history.slice(0, 8)));
  renderHistory();
}

function renderHistory() {
  const history = getHistory();
  const empty = document.getElementById("history-empty");
  const table = document.getElementById("history-table");
  const body = document.getElementById("history-body");
  const total = history.length;
  const counts = {
    Safe: history.filter((item) => item.status === "Safe").length,
    Suspicious: history.filter((item) => item.status === "Suspicious").length,
    Phishing: history.filter((item) => item.status === "Phishing").length
  };

  document.getElementById("history-total").textContent = String(total).padStart(2, "0");
  document.getElementById("safe-count").textContent = String(counts.Safe).padStart(2, "0");
  document.getElementById("suspicious-count").textContent = String(counts.Suspicious).padStart(2, "0");
  document.getElementById("phishing-count").textContent = String(counts.Phishing).padStart(2, "0");
  document.getElementById("safe-bar").style.width = total ? `${(counts.Safe / total) * 100}%` : "0%";
  document.getElementById("suspicious-bar").style.width = total ? `${(counts.Suspicious / total) * 100}%` : "0%";
  document.getElementById("phishing-bar").style.width = total ? `${(counts.Phishing / total) * 100}%` : "0%";

  empty.hidden = total > 0;
  table.hidden = total === 0;
  body.innerHTML = history.map((item) => {
    const date = new Date(item.timestamp);
    const time = Number.isNaN(date.getTime()) ? "—" : date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    return `<tr>
      <td title="${escapeHtml(item.url)}">${escapeHtml(item.url)}</td>
      <td><span class="table-badge table-${statusClass(item.status)}">${escapeHtml(item.status.toUpperCase())}</span></td>
      <td>${escapeHtml(item.score)}%</td>
      <td>${time}</td>
    </tr>`;
  }).join("");
}

async function scanUrl(event) {
  event.preventDefault();
  clearError();
  const url = input.value.trim();
  if (!url) {
    showError("Enter a URL to scan.");
    input.focus();
    return;
  }

  scanButton.disabled = true;
  scanButton.classList.add("is-loading");
  scanButton.querySelector(".scan-label").textContent = "Analyzing...";
  try {
    const response = await fetch("/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Unable to analyze this URL.");
    renderResult(data);
    saveHistory(data);
  } catch (error) {
    showError(error.message || "The scan could not be completed.");
  } finally {
    scanButton.disabled = false;
    scanButton.classList.remove("is-loading");
    scanButton.querySelector(".scan-label").textContent = "Scan URL";
  }
}

form.addEventListener("submit", scanUrl);
document.querySelectorAll(".sample-button").forEach((button) => {
  button.addEventListener("click", () => {
    input.value = button.dataset.url || "";
    input.focus();
  });
});

document.getElementById("clear-history").addEventListener("click", () => {
  localStorage.removeItem(historyKey);
  renderHistory();
});

const menuToggle = document.getElementById("menu-toggle");
const mobileNav = document.getElementById("mobile-nav");
menuToggle.addEventListener("click", () => {
  const isOpen = mobileNav.classList.toggle("is-open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
mobileNav.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => {
  mobileNav.classList.remove("is-open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

renderHistory();